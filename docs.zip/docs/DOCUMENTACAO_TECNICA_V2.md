# MindClass — Documentação Técnica (versão 2)

Plataforma web de organização escolar com três perfis (**Professor**, **Aluno** e **Administração**): turmas, grade de horários, notas por trimestre com histórico imutável, atividades, calendário, relatórios e notificações em tempo real.

*Substitui `DOCUMENTACAO_TECNICA.md` (versão 1).*

| Item | Valor |
|---|---|
| Tipo | SPA + API REST + banco relacional |
| Backend | Node.js ≥ 22.13, módulo `http` nativo |
| Banco | PostgreSQL (Supabase) **ou** SQLite local (`node:sqlite`) |
| Dependências | Apenas `pg` (driver PostgreSQL) |
| Frontend | HTML, CSS e JavaScript puro (ES modules), sem framework nem build |
| Tempo real | Server-Sent Events (SSE) |
| Autenticação | Sessão por cookie `HttpOnly`; senhas com `scrypt` |
| Idioma | pt-BR |

**Situação da integração com o Supabase:** o código está pronto e o esquema SQL foi aplicado no projeto, mas a conexão do servidor com o banco **ainda não foi testada** (depende do arquivo `.env` com a senha). Sem `.env`, o sistema usa o SQLite local.

---

## 1. Estrutura do projeto

```
organizador.escolar/
├── server.js                 API principal, sessão, permissões, SSE, arquivos estáticos
├── admin.js                  Rotas da administração
├── relatorios.js             Relatórios e consulta do histórico de notas
├── auth.js                   Hash de senha e política de senhas
├── db.js                     Escolhe o banco (PostgreSQL ou SQLite)
├── db-postgres.js            Adaptador PostgreSQL/Supabase
├── db-sqlite.js              Adaptador SQLite: esquema e migrações
├── dados.js                  Horários-padrão, turmas oficiais e matérias
├── criar-admin.js            Cria um administrador pelo terminal
├── copiar-para-supabase.js   Copia contas reais do banco local para o Supabase
├── dev.js                    Ambiente de teste com dados de exemplo
├── test.js                   Testes de integração (190 verificações)
├── .env.exemplo              Modelo de configuração
├── supabase/schema.sql       Criação das tabelas no Supabase
├── migracoes/002_*.sql       Migração do SQLite (histórico, auditoria, índices)
├── data/                     Bancos SQLite (fora do versionamento)
├── docs/                     Documentação
└── public/
    ├── index.html            Casca da página
    ├── app.js                Núcleo: rotas, telas de aluno e professor, sessão
    ├── calendario.js         Calendário
    ├── relatorios.js         Relatórios e gráficos
    ├── historico.js          Histórico de notas
    ├── admin.js              Painel administrativo
    ├── app.css               Base visual e tokens
    ├── extra.css             Componentes e adaptações
    ├── modulos.css           Estilos dos módulos e impressão
    ├── grid.css              Sistema de grid e responsividade (carregado por último)
    └── logo.webp             Logo/mascote
```

## 2. Instalação e execução

```bash
npm install
```

| Comando | O que faz | Banco |
|---|---|---|
| `npm start` | Sobe o sistema em `http://localhost:3000` | Supabase se houver `.env`; senão `data/organizae.db` |
| `npm run teste` | Ambiente de teste (mantém os dados) | `data/teste.db` |
| `npm run teste:reset` | **Apaga** o banco de teste e recria os exemplos | `data/teste.db` |
| `npm test` | Testes automáticos em banco temporário | SQLite |
| `npm run criar-admin` | Cria um administrador | o mesmo do `npm start` |
| `npm run copiar-supabase` | Lista as contas locais a copiar (`-- --confirmar` grava) | origem SQLite → Supabase |

Contas do ambiente de teste (senha `teste1234`): `admin@teste.com`, `prof@teste.com`, `prof2@teste.com`, `aluno@teste.com`, `aluno2@teste.com`, `aluno3@teste.com`. Elas existem **somente** no banco de teste.

### 2.1 Variáveis de ambiente

| Variável | Padrão | Função |
|---|---|---|
| `DATABASE_URL` | — | String de conexão PostgreSQL. Ativa o Supabase |
| `DATABASE_CA` | — | Certificado para verificar a conexão TLS |
| `DB_PATH` | `data/organizae.db` | Caminho do SQLite. Quando definido, **ignora** `DATABASE_URL` |
| `PORT` | `3000` | Porta HTTP |
| `HOST` | `127.0.0.1` | Endereço de escuta |
| `COOKIE_SECURE` | — | `1` em produção com HTTPS (cookie `Secure` e HSTS) |
| `ADMIN_SENHA` | — | Senha para `criar-admin` sem interação (automação) |

### 2.2 Conectar ao Supabase

1. No **SQL Editor**, executar `supabase/schema.sql` (pode ser repetido sem apagar dados).
2. Copiar `.env.exemplo` para `.env` e colar a string **Session pooler** (o endereço direto do banco só tem IPv6). Codificar caracteres especiais da senha (`@` → `%40`).
3. `npm run criar-admin` e depois `npm start`. O terminal deve mostrar `Banco de dados: PostgreSQL (Supabase)`.

## 3. Arquitetura

```
Navegador (SPA)               Servidor Node                       Banco
┌──────────────────┐  JSON   ┌───────────────────────┐   db.*    ┌─────────────────────┐
│ app.js + módulos │ ──────► │ rotas /api            │ ────────► │ db.js               │
│ roteador por #   │ ◄────── │ valida · autentica ·  │ ◄──────── │ ├ db-postgres (.env)│
│ data-act/-form   │   SSE   │ autoriza              │           │ └ db-sqlite         │
└──────────────────┘ ◄────── │ notificações/lembretes│           └─────────────────────┘
                             └───────────────────────┘
```

- **O servidor é a fonte da verdade:** toda permissão e validação acontece no backend.
- **O navegador nunca acessa o Supabase diretamente.** A chave publicável não é usada pelo sistema e não tem acesso às tabelas.
- **Sem JavaScript inline:** permite uma Content-Security-Policy estrita.

### 3.1 Camada de banco

Os dois adaptadores oferecem a mesma interface assíncrona:

| Método | Retorno |
|---|---|
| `db.get(sql, ...params)` | primeira linha ou `undefined` |
| `db.all(sql, ...params)` | lista de linhas |
| `db.run(sql, ...params)` | `{ changes }` |
| `db.tx(async () => …)` | executa em transação |

Regras para escrever SQL compatível com os dois bancos:

- Parâmetros sempre com `?` (o adaptador converte para `$1…`).
- Para obter o ID inserido: `INSERT … RETURNING id`.
- Usar `ON CONFLICT DO NOTHING`, `CASE WHEN` em somas condicionais, `string_agg(CAST(x AS TEXT), ', ')`, `date(coluna)` e `lower()` para buscas.
- Dentro de uma transação, executar as consultas em sequência.

No SQLite há uma única conexão: durante uma transação, as demais consultas aguardam. No PostgreSQL há um *pool* de até 8 conexões, e a transação usa uma conexão exclusiva (via `AsyncLocalStorage`). O adaptador converte os tipos do PostgreSQL para os formatos esperados (datas `AAAA-MM-DD`, horas `HH:MM`, números).

## 4. Modelo de dados

| Tabela | Finalidade | Campos principais |
|---|---|---|
| `usuarios` | Contas | nome, e-mail único, `senha_hash`, `salt`, `perfil`, foto, `ativo`, `ultimo_login`, `senha_alterada_em` |
| `professores` | Dados do professor | turno |
| `alunos` | Dados do aluno | matrícula |
| `materias` / `turmas` | Cadastros | turmas têm `etapa` e `num_horarios` |
| `professor_materias` / `professor_turmas` | Vínculos | `aprovado` (0 = pendente) |
| `aluno_turmas` | Turma do aluno | |
| `horarios` | Grade | turma, matéria, professor, `dia` (1–5), `slot`, início, fim |
| `calendario` | Compromissos | autor, turma (nulo = pessoal), matéria, título, `categoria`, data, horários |
| `notas` | Notas atuais | `trimestre` (1–3), `valor` (0–10); única por aluno/matéria/trimestre |
| `notas_historico` | **Imutável** | anterior, nova, ação, professor, responsável, ano, data, origem |
| `atividades` / `atividades_concluidas` | Tarefas e marcações | prazo |
| `notificacoes` | Caixa de avisos | tipo, `chave` (evita repetição), `lida` |
| `sessoes` | Sessões | hash do token, `expira_em`, `ultimo_uso` |
| `auditoria` | **Imutável** | quem, ação, alvo, detalhe, IP, data |

- Gatilhos no banco impedem `UPDATE` e `DELETE` em `notas_historico` e `auditoria`.
- No Supabase, as 17 tabelas têm **RLS ligado sem políticas** e acesso revogado de `anon` e `authenticated`.
- A tabela `eventos` existe apenas no SQLite (legada, sem uso).

### 4.1 Migrações do SQLite (automáticas)

Ao iniciar, `db-sqlite.js` acrescenta colunas que faltam, reconstrói `usuarios` para aceitar o perfil administrador, renomeia `bimestre` para `trimestre`, cria histórico e auditoria e registra as notas já existentes (origem `migracao`). Antes das mudanças estruturais é criada uma cópia de segurança do arquivo. Notas antigas de um 4º período são preservadas e aparecem no histórico, mas ficam fora das telas de notas e das médias.

### 4.2 Turmas e horários

| Turmas | Horários por dia |
|---|---:|
| 6º ao 9º ano, A e B | 5 |
| 1º ano Administração | 7 |
| 1º ano Agronegócio, 2º ano Alimentos, 3º ano Informática | 9 |
| 3º ano Regular | 6 |

| Aula | Horário | Aula | Horário |
|---:|---|---:|---|
| 1ª | 07:00–07:50 | 6ª | 11:30–12:20 |
| 2ª | 07:50–08:40 | 7ª | 13:30–14:20 |
| 3ª | 08:40–09:30 | 8ª | 14:20–15:10 |
| 4ª | 09:50–10:40 | 9ª | 15:10–16:00 |
| 5ª | 10:40–11:30 | | |

Intervalo após a 3ª aula; almoço após a 6ª.

## 5. Autenticação, sessões e segurança

- **Senhas:** 8 a 100 caracteres, com letra e número; recusa senhas comuns e que contenham o e-mail. Hash `scrypt` assíncrono com *salt*; comparação em tempo constante, calculada mesmo para e-mail inexistente.
- **Sessão:** cookie `HttpOnly; SameSite=Strict`; validade de 7 dias e expiração após 12 h sem uso. O banco guarda só o SHA-256 do token.
- Trocar a senha encerra as outras sessões; há "sair de todos os dispositivos". Desativar uma conta ou redefinir a senha derruba as sessões.
- **Limites:** login 10 falhas/15 min por IP e e-mail e 40 por IP; cadastro 60/hora por IP; 5 conexões em tempo real por usuário.
- **Anti-CSRF:** `SameSite`, exigência de JSON, checagem de `Origin` e `Sec-Fetch-Site`.
- **Cabeçalhos:** CSP, `nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Permissions-Policy`, COOP/CORP; HSTS com `COOKIE_SECURE=1`.
- SQL sempre parametrizado, escape de HTML no frontend, proteção contra *path traversal*, corpo limitado a 700 KB, fotos até ~300 KB.
- Contas de administrador não podem ser criadas pelo cadastro público.
- **TLS com o Supabase:** sem `DATABASE_CA`, a conexão é criptografada, mas o certificado não é verificado.

## 6. Permissões

| Recurso | Aluno | Professor (vínculo aprovado) | Administração |
|---|---|---|---|
| Notas | Vê as próprias | Lança/edita nas suas matérias e turmas | Consulta por relatórios e histórico |
| Histórico de notas | Só o próprio | Suas turmas **e** matérias | Tudo |
| Horários | Vê a sua turma | Edita os próprios; outras matérias aparecem como "Ocupado" | Vê qualquer turma |
| Atividades | Vê e marca concluída | Cria e edita as próprias | Consulta |
| Calendário | Eventos pessoais | Pessoais e das suas turmas | Eventos de turma (inclusive de outros) |
| Relatórios | Individual | Turmas e alunos vinculados, só suas matérias | Todos |
| Usuários, aprovações, auditoria | — | — | Sim |

O professor **solicita** turmas e matérias; nada é liberado antes da aprovação.

## 7. API

Base `/api`, JSON. Mutações exigem `Content-Type: application/json`.

| Grupo | Rotas |
|---|---|
| Público | `GET /opcoes` · `POST /cadastro/aluno` · `POST /cadastro/professor` · `POST /login` · `GET /eu` |
| Conta | `POST /logout` · `POST /logout-todas` · `PATCH /perfil` · `PUT /professor/vinculos` |
| Painel | `GET /painel` (aluno/professor) · `GET /professor/resumo` |
| Turmas e notas | `GET /turmas/:id/alunos` · `GET, PUT /notas` · `DELETE /notas/:id` · `GET /aluno/notas` · `GET /aluno/professores` |
| Horários | `GET, POST /horarios` · `PUT, DELETE /horarios/:id` |
| Atividades | `GET, POST /atividades` · `PUT, DELETE /atividades/:id` · `PUT /atividades/:id/concluida` · `POST /avisos` |
| Calendário | `GET /calendario?de&ate&turma_id&materia_id&categoria` · `GET, POST /agenda` · `PUT, DELETE /agenda/:id` |
| Relatórios | `GET /relatorios/aluno` · `GET /relatorios/turma` · `GET /historico-notas` |
| Notificações | `GET /notificacoes` · `POST /notificacoes/ler-todas` · `PATCH, DELETE /notificacoes/:id` · `GET /eventos` (SSE) |
| Administração | `GET /admin/resumo` · `GET, POST /admin/usuarios` · `PATCH /admin/usuarios/:id` · `POST /admin/usuarios/:id/senha` · `GET, POST /admin/pendencias` · `PUT /admin/professores/:id/vinculos` · `POST /admin/materias` · `GET /admin/auditoria` |

Erros: `400` validação · `401` sem sessão · `403` sem permissão · `404` não encontrado · `409` conflito · `413` corpo grande · `415` tipo inválido · `429` excesso de tentativas.

## 8. Regras de negócio

- **Horários:** o `slot` não pode passar de `num_horarios`; não há choque de turma nem de professor.
- **Calendário:** categorias prova, trabalho, atividade, evento, reunião e outro; bloqueia duplicados e conflitos na mesma turma (ou entre eventos pessoais). Sem término, considera 1 hora. Prazos de atividades aparecem automaticamente.
- **Notas:** arredondadas a uma casa; só alteração de valor gera histórico.
- **Relatórios:** média mínima 6,0. Atenção: média abaixo de 6 ou queda de 1 ponto ou mais no último trimestre. A média geral é a média das médias por matéria. Atividades não são divididas por trimestre.
- **Notificações:** nota, horário, atividade, lembrete (48 h, verificado a cada 5 min), aviso, turma, evento e vínculo. Lidas com mais de 90 dias são removidas.

## 9. Frontend

- **Rotas (hash):** `#/`, `#/entrar[/perfil]`, `#/cadastro/{aluno|professor}`, `#/inicio` e as telas do menu de cada perfil.
- **Módulos:** cada um exporta `VIEWS`, `ACTIONS`, `CHANGE`, `SUBMIT` (e opcionalmente `AFTER`); `app.js` os combina por perfil.
- **Atualização automática:** o evento SSE `atualizacao` recarrega a tela afetada, desde que não haja formulário sendo preenchido.
- **PDF:** "Exportar PDF" usa a impressão do navegador com folha de estilo própria.

### 9.1 Design responsivo

| Faixa | Navegação | Layout |
|---|---|---|
| até 768 px | barra inferior com 4 itens + "Menu" | 1 coluna |
| 769–1199 px | trilho lateral de ícones | 1–2 colunas |
| 1200 px ou mais | menu lateral de 240 px | grid de 12 colunas, conteúdo até 1280 px |

Utilitários em `grid.css`: `.grid` com `.col-*`, `.stack`, `.painel`, `.cards` e `.split` (painel lateral por *container query*). Cabeçalho e conteúdo compartilham as mesmas margens. Tema claro/escuro por `data-theme`, salvo no navegador. Fontes Nunito e DM Sans.

## 10. Desempenho

Painel inicial em uma requisição; compressão gzip; arquivos estáticos com ETag; índices nas consultas frequentes; cache de opções no navegador e de dados do calendário.

Há consultas repetidas dentro de laços (notificações por aluno e lembretes). Com o banco remoto, isso aumenta o tempo dessas operações em turmas grandes; agrupar essas inserções é a melhoria recomendada.

## 11. Testes

`npm test` — 190 verificações no **SQLite**: cadastro e senhas, sessões, segurança das requisições, permissões, aprovação de vínculos, notas e histórico imutável, relatórios com valores conferidos, horários, calendário, tempo real, administração e migração de banco antigo.

Conferências manuais no navegador: telas dos três perfis sem erro e verificações de largura entre 375 e 1728 px.

**Não testado:** execução contra o PostgreSQL/Supabase, o script de cópia, o PDF impresso e a migração de um banco real em uso.

## 12. Limitações

- Integração com o Supabase pendente de configuração e validação.
- Servidor de processo único: limites de tentativas e conexões SSE ficam em memória.
- Sem recuperação de senha por e-mail nem push com o navegador fechado.
- O aluno escolhe a própria turma no cadastro (a administração pode corrigir).
- Turmas e horários das aulas são definidos no código (e em `schema.sql`).
- Publicação na internet exige HTTPS, `COOKIE_SECURE=1`, `HOST` adequado e certificado do banco.

## 13. Como estender

| Necessidade | Onde mexer |
|---|---|
| Turmas ou horários | `dados.js` **e** `supabase/schema.sql` |
| Nova tabela ou coluna | `db-sqlite.js` (com `ALTER TABLE` condicional) **e** `supabase/schema.sql` |
| Nova rota | `rota(método, caminho, {auth}, async …)`; validar a entrada e conferir o vínculo; usar `await` em toda chamada ao banco |
| Nova tela | módulo em `public/` ou `app.js` + item em `MENU` |
| Visual | tokens em `app.css`; layout em `grid.css` |

> Atenção: esquecer o `await` numa função de permissão (`leciona`, `ensinaTurma`, `podeNota`) faz a checagem passar sempre. Rode `npm test` após qualquer mudança nessas rotas.
