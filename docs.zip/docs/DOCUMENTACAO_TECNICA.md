# MindClass — Documentação Técnica

> **Atenção:** este texto descreve a versão 1. Onde houver diferença (perfil administrador, sessões, histórico de notas, relatórios, calendário, testes), vale [ALTERACOES_V2.md](ALTERACOES_V2.md).

Plataforma escolar web com dois perfis de usuário (**Professor** e **Aluno**): gestão de turmas, grade de horários, notas, atividades, calendário de eventos e notificações em tempo real.

| Item | Valor |
|---|---|
| Nome do produto | MindClass |
| Tipo | Aplicação web (SPA) + API REST + banco relacional |
| Backend | Node.js (≥ 22.13), módulo `http` nativo, **sem dependências externas** |
| Banco de dados | SQLite embutido (`node:sqlite`), arquivo único |
| Frontend | HTML + CSS + JavaScript puro (ES modules), sem framework e sem etapa de build |
| Tempo real | Server-Sent Events (SSE) |
| Autenticação | Sessão por cookie `HttpOnly`, senhas com `scrypt` |
| Idioma | Português (pt-BR) |

---

## 1. Estrutura do projeto

```
organizador.escolar/
├── server.js            API REST, autenticação, permissões, SSE, arquivos estáticos (546 linhas)
├── db.js                Esquema do banco, migração, turmas oficiais, horários-padrão (168 linhas)
├── dev.js               Ambiente de teste com banco separado e dados de exemplo (50 linhas)
├── test.js              Teste de integração da API e das permissões (102 verificações)
├── package.json         Scripts: start, test, teste, teste:reset
├── .claude/launch.json  Configuração do servidor de preview (usa dev.js --reset)
├── data/                Bancos SQLite (criada automaticamente; fora do versionamento)
│   ├── organizae.db     Banco de produção/uso real (nome mantido para preservar dados)
│   └── teste.db         Banco do ambiente de teste
├── public/              Tudo que o navegador recebe
│   ├── index.html       Casca da página (carrega CSS e o módulo app.js)
│   ├── app.js           Aplicação inteira: rotas, telas, ações, formulários (680 linhas)
│   ├── app.css          Base visual herdada do design original (tokens, componentes)
│   ├── extra.css        Camada atual: componentes novos, tema escuro, mobile (326 linhas)
│   └── logo.webp        Logo/mascote
└── docs/DOCUMENTACAO_TECNICA.md
```

## 2. Como executar

| Comando | O que faz |
|---|---|
| `npm start` | Sobe o servidor com o banco real `data/organizae.db` em `http://localhost:3000` |
| `npm run teste` | Sobe com o banco de teste `data/teste.db` (mantém os dados) e cria dados de exemplo se estiver vazio |
| `npm run teste:reset` | Apaga `teste.db` e recria com os dados de exemplo |
| `npm test` | Executa `test.js`: sobe o servidor numa porta própria (3111) com banco temporário, roda 102 verificações e apaga tudo |

Variáveis de ambiente: `PORT` (padrão 3000) e `DB_PATH` (caminho do arquivo SQLite).
O servidor escuta apenas em `127.0.0.1` (acesso somente do próprio computador).

**Contas do ambiente de teste** (senha `teste1234`): professores `prof@teste.com`, `prof2@teste.com`; alunos `aluno@teste.com`, `aluno2@teste.com`, `aluno3@teste.com`.

## 3. Arquitetura

```
Navegador (SPA, app.js)                      Servidor (server.js)                 Banco
┌────────────────────────┐   fetch JSON    ┌──────────────────────────┐   SQL   ┌────────────┐
│ roteador por hash (#/) │ ──────────────► │ roteador de rotas /api/* │ ──────► │  SQLite    │
│ telas = funções que    │ ◄────────────── │ valida • autentica •     │ ◄────── │ (db.js)    │
│ devolvem HTML          │                 │ autoriza • grava         │         └────────────┘
│ delegação de eventos   │   SSE (eventos) │ notificar() ─► streams   │
│ data-act / data-form   │ ◄────────────── │ lembretes a cada 5 min   │
└────────────────────────┘                 └──────────────────────────┘
```

Princípios adotados:

1. **O servidor é a fonte da verdade.** Toda regra de permissão e validação roda em `server.js`; a interface só reflete essas regras (botões ocultos não são segurança).
2. **Sem dependências.** Nada de `node_modules`; o banco é o `node:sqlite` do próprio Node.
3. **Sem scripts inline.** Todo o JavaScript fica em `app.js`, o que permite uma Content-Security-Policy estrita.
4. **Eventos por delegação.** O HTML usa atributos `data-act`, `data-form` e `data-change`; um único listener por tipo de evento resolve a ação.

## 4. Modelo de dados

Banco SQLite com `PRAGMA foreign_keys=ON` e `journal_mode=WAL`. Exclusão de usuário/turma/matéria propaga em cascata para os vínculos.

| Tabela | Finalidade | Campos principais |
|---|---|---|
| `usuarios` | Conta e login | `id`, `nome`, `email` (único, sem diferenciar maiúsculas), `senha_hash`, `salt`, `perfil` (`professor`\|`aluno`), `foto` (data URL), `criado_em` |
| `professores` | Dados do professor | `usuario_id` (PK/FK), `turno` (`manhã`\|`tarde`\|`noite`\|`integral`) |
| `alunos` | Dados do aluno | `usuario_id` (PK/FK), `matricula` |
| `materias` | Disciplinas | `id`, `nome` (único) |
| `turmas` | Turmas | `id`, `nome` (único), `etapa` (`fundamental`\|`medio`\|`outra`), `num_horarios` |
| `professor_materias` | N:N professor × matéria | PK composta |
| `professor_turmas` | N:N professor × turma | PK composta |
| `aluno_turmas` | N:N aluno × turma | PK composta |
| `horarios` | Aulas da grade | `turma_id`, `materia_id`, `professor_id`, `dia` (1–5), `slot`, `inicio`, `fim` |
| `notas` | Notas por trimestre | `aluno_id`, `materia_id`, `professor_id`, `trimestre` (1–3), `valor` (0–10), `descricao`; **único** por (aluno, matéria, trimestre) |
| `atividades` | Tarefas | `turma_id`, `materia_id`, `professor_id`, `titulo`, `descricao`, `prazo` (`AAAA-MM-DDTHH:MM`) |
| `atividades_concluidas` | Marcação pessoal do aluno | PK (aluno, atividade) |
| `calendario` | Eventos do calendário | `usuario_id` (autor), `turma_id` (nulo = pessoal), `titulo`, `descricao`, `data`, `inicio`/`fim` opcionais |
| `notificacoes` | Caixa de notificações | `usuario_id`, `tipo`, `titulo`, `mensagem`, `chave`, `lida`, `criado_em` |
| `sessoes` | Sessões ativas | `token_hash` (SHA-256), `usuario_id`, `expira_em` |

Observações:

- Restrições `CHECK` no banco: `dia` entre 1 e 5, `valor` entre 0 e 10, `trimestre` entre 1 e 3, `inicio < fim`.
- `notificacoes.chave` + índice único parcial `(usuario_id, chave)` evita lembretes duplicados.
- A tabela `eventos` é **legada** (versão anterior dos eventos, por dia da semana). Foi substituída por `calendario` e não é mais usada; foi mantida para não descartar dados.
- Datas/horas são texto: hora local para prazos e horários, ISO UTC (`toISOString`) para `criado_em`.

### 4.1 Migração (bancos antigos)

Ao iniciar, `db.js` verifica as colunas existentes e, se faltarem, executa `ALTER TABLE` para `turmas.etapa`, `turmas.num_horarios` e `horarios.slot`. Horários antigos recebem o `slot` cujo início é o mais próximo. Turmas antigas ficam com `etapa='outra'` e `num_horarios=9`. Nenhum dado é apagado.

### 4.2 Turmas oficiais e horários

As turmas abaixo são criadas/atualizadas a cada inicialização (`INSERT … ON CONFLICT DO UPDATE`):

| Etapa | Turma | Horários por dia |
|---|---|---:|
| Fundamental | 6º, 7º, 8º e 9º ano — A e B (8 turmas) | 5 |
| Médio | 1º ano Administração | 7 |
| Médio | 1º ano Agronegócio | 9 |
| Médio | 2º ano Alimentos | 9 |
| Médio | 3º ano Informática | 9 |
| Médio | 3º ano Regular | 6 |

Horários-padrão de cada aula (constante `SLOTS` em `db.js`; cada turma usa as primeiras *N*):

| Aula | Início | Fim | | Aula | Início | Fim |
|---:|---|---|---|---:|---|---|
| 1ª | 07:00 | 07:50 | | 6ª | 11:30 | 12:20 |
| 2ª | 07:50 | 08:40 | | 7ª | 13:30 | 14:20 |
| 3ª | 08:40 | 09:30 | | 8ª | 14:20 | 15:10 |
| 4ª | 09:50 | 10:40 | | 9ª | 15:10 | 16:00 |
| 5ª | 10:40 | 11:30 | | | | |

Intervalo: 09:30–09:50 (após a 3ª). Almoço: 12:20–13:30 (após a 6ª). Para mudar os horários da escola, basta editar `SLOTS`.

Matérias iniciais: Matemática, Português, História, Geografia, Biologia, Física, Química, Inglês, Educação Física, Informática, Artes, Filosofia, Sociologia (o professor pode criar outras no cadastro).

## 5. Autenticação e sessão

- **Senha:** mínimo 8 e máximo 100 caracteres; armazenada com `scrypt` (64 bytes) e *salt* aleatório de 16 bytes; comparação em tempo constante (`timingSafeEqual`).
- **Sessão:** token aleatório de 32 bytes enviado em cookie `sid` (`HttpOnly; SameSite=Strict; Path=/; Max-Age=14 dias`). No banco fica apenas o **hash SHA-256** do token. Sessões expiradas são limpas a cada 5 minutos.
- **Login:** o front envia também o perfil escolhido (aba Aluno/Professor); se a conta for de outro perfil, o servidor responde `403`.
- **Proteção contra tentativas:** no máximo 10 falhas por 15 minutos para cada par IP + e-mail (`429`).
- **Troca de senha:** exige a senha atual.
- **Foto de perfil:** aceita só PNG/JPEG/WebP/GIF em *data URL*, até ~300 KB; o navegador reduz a imagem para 192×192 antes de enviar.

## 6. Permissões

Verificadas no servidor em cada requisição. A tabela resume o que cada perfil pode fazer.

| Recurso | Professor | Aluno |
|---|---|---|
| Notas | Lançar, editar e excluir **apenas** se leciona a matéria **e** o aluno é de uma turma dele | Ver só as próprias (somente leitura) |
| Horários | Criar/editar/excluir só os **próprios**; ver a grade das turmas a que está vinculado, mas apenas aulas das matérias que leciona (as demais aparecem como "Ocupado") | Ver a grade da própria turma |
| Atividades | Criar/editar/excluir só as próprias, em turmas/matérias vinculadas | Ver as da própria turma; marcar como concluída (marcação pessoal) |
| Avisos | Enviar à turma a que está vinculado | — |
| Alunos da turma | Listar alunos das turmas vinculadas | — |
| Calendário | Eventos pessoais ou para uma turma vinculada (avisa os alunos) | Eventos **só pessoais** |
| Eventos de terceiros | Nunca edita/exclui eventos de outro usuário | Idem |
| Notificações | Só as próprias | Só as próprias |
| Matérias/turmas do professor | Pode alterar os próprios vínculos (Perfil) | — |

Regra central de "leciona": existe linha em `professor_turmas` para a turma **e** em `professor_materias` para a matéria. Para notas, a turma é descoberta pelo vínculo do aluno (`aluno_turmas`).

Códigos de resposta: `401` sem login, `403` sem permissão, `404` inexistente, `409` conflito (e-mail duplicado, choque de horário), `400` validação, `415` Content-Type inválido, `429` excesso de tentativas, `413` corpo grande.

## 7. API REST

Base: `/api`. Corpo e resposta em JSON. Mutações exigem `Content-Type: application/json`. "Auth" indica quem pode chamar (`—` = público).

### 7.1 Público e conta

| Método | Rota | Auth | Descrição |
|---|---|---|---|
| GET | `/opcoes` | — | Matérias, turmas (com `etapa`, `num_horarios`), horários-padrão (`slots`) e turnos |
| POST | `/cadastro/professor` | — | Cria professor: nome, e-mail, senha, confirmação, turno, `materias[]`, `novas_materias[]`, `turmas[]`, foto opcional. Já inicia a sessão |
| POST | `/cadastro/aluno` | — | Cria aluno: nome, e-mail, senha, confirmação, `turma_id`, matrícula opcional. Avisa os professores da turma |
| POST | `/login` | — | E-mail, senha e (opcional) perfil esperado |
| POST | `/logout` | qualquer | Encerra a sessão |
| GET | `/eu` | — | Perfil do usuário logado (ou `{anonimo:true}`) |
| PATCH | `/perfil` | qualquer | Nome, foto, turno (professor), troca de senha |
| PUT | `/professor/vinculos` | professor | Substitui matérias e turmas do professor |

### 7.2 Professor

| Método | Rota | Descrição |
|---|---|---|
| GET | `/professor/resumo` | Turmas com contagem de alunos, nº de aulas e atividades abertas |
| GET | `/turmas/:id/alunos` | Alunos da turma (só turmas vinculadas) |
| GET | `/notas?turma_id=&materia_id=` | Alunos da turma com as notas da matéria |
| PUT | `/notas` | Cria/atualiza nota (`aluno_id`, `materia_id`, `trimestre`, `valor`, `descricao`) |
| DELETE | `/notas/:id` | Exclui nota |
| POST | `/avisos` | Envia aviso à turma (`turma_id`, `titulo`, `mensagem`) |

### 7.3 Aluno

| Método | Rota | Descrição |
|---|---|---|
| GET | `/aluno/notas` | Notas agrupadas por matéria, com média |
| GET | `/aluno/professores` | Professores vinculados à turma |
| PUT | `/atividades/:id/concluida` | Marca/desmarca atividade como concluída |

### 7.4 Horários, atividades, calendário (ambos os perfis, com regras por perfil)

| Método | Rota | Auth | Descrição |
|---|---|---|---|
| GET | `/horarios` | todos | Aluno: grade da turma. Professor: próprios horários, ou `?turma_id=` para a grade filtrada da turma |
| POST | `/horarios` | professor | `turma_id`, `materia_id`, `dia` (1–5), `slot` (1…N da turma) |
| PUT/DELETE | `/horarios/:id` | professor | Só o autor |
| GET | `/atividades` | todos | Professor: as próprias. Aluno: as da turma (com `concluida`) |
| POST | `/atividades` | professor | `turma_id`, `materia_id`, `titulo`, `descricao`, `prazo` |
| PUT/DELETE | `/atividades/:id` | professor | Só o autor |
| GET | `/agenda` | todos | Eventos do usuário (aluno também vê os da turma) |
| POST | `/agenda` | todos | `titulo`, `data` (`AAAA-MM-DD`), `inicio`/`fim` opcionais, `descricao`, `turma_id` (só professor) |
| PUT/DELETE | `/agenda/:id` | todos | Só o autor |

Validações de horário: `slot` entre 1 e `num_horarios` da turma (ex.: `400` ao pedir o 6º horário numa turma do Fundamental); choque com outra aula da mesma turma ou do mesmo professor no mesmo dia/horário retorna `409`.

### 7.5 Notificações

| Método | Rota | Descrição |
|---|---|---|
| GET | `/notificacoes` | Até 200 mais recentes + contador de não lidas |
| PATCH | `/notificacoes/:id` | Marca como lida/não lida (`{lida:true\|false}`) |
| POST | `/notificacoes/ler-todas` | Marca todas como lidas |
| DELETE | `/notificacoes/:id` | Exclui |
| GET | `/eventos` | Canal **SSE**: envia o evento `notificacao` em tempo real |

## 8. Notificações em tempo real

`notificar(usuarioId, tipo, titulo, mensagem, chave?)` grava no banco e, se o usuário tiver uma aba conectada, empurra o evento pelo SSE (`event: notificacao`). O servidor mantém um mapa `usuário → conexões` em memória e envia um *ping* a cada 25 s.

| Tipo | Quando é gerada | Destinatário |
|---|---|---|
| `nota` | Nota lançada, alterada ou removida | Aluno |
| `horario` | Aula adicionada/alterada/cancelada | Alunos da turma e o próprio professor |
| `atividade` | Atividade publicada, atualizada ou cancelada | Alunos da turma |
| `lembrete` | Prazo em até 48 h (verificação ao iniciar, a cada 5 min e ao publicar/editar atividade) | Alunos que ainda não concluíram + professor |
| `aviso` | Boas-vindas e avisos enviados pelo professor | Aluno / novo usuário |
| `turma` | Novo aluno vinculado à turma | Professores da turma |
| `evento` | Evento de turma criado/alterado/cancelado | Alunos da turma |

No navegador, a chegada de uma notificação mostra um *toast*, atualiza o contador do sino e, se a aba estiver em segundo plano e o usuário tiver autorizado, dispara uma notificação nativa do navegador (Notification API). Para o aluno, a tela atual é recarregada quando o evento afeta nota, horário, atividade ou calendário.

## 9. Frontend

### 9.1 Roteamento (hash)

| Rota | Quem | Tela |
|---|---|---|
| `#/` | todos | Página inicial (apresentação, logo, botões de acesso) |
| `#/entrar[/aluno\|/professor]` | visitante | Login |
| `#/cadastro/aluno`, `#/cadastro/professor` | visitante | Cadastros |
| `#/inicio` | logado | Painel (resumo, aulas de hoje, resumo de atividades) |
| `#/notas` | ambos | Professor: lançar notas. Aluno: notas e médias |
| `#/horarios` | ambos | Grade por horários (professor edita) |
| `#/calendario` | ambos | Calendário mensal de eventos |
| `#/atividades` | ambos | Professor: publicar/gerenciar. Aluno: pendentes/histórico |
| `#/professores` | aluno | Professores da turma |
| `#/alunos`, `#/avisos` | professor | Lista de alunos e envio de avisos |
| `#/notificacoes`, `#/perfil` | ambos | Histórico de notificações; dados da conta |

`route()` decide a tela pelo hash e pelo perfil; rotas fora do menu do perfil caem no `#/inicio`. Um contador (`S.nav`) descarta respostas atrasadas quando o usuário navega rápido.

### 9.2 Organização do `app.js`

- **Estado global** `S`: usuário, notificações, seleções de tela (turma, mês/dia do calendário, edição em andamento).
- **Infra:** `api()` (fetch com tratamento de erro/401), `toast()`, `esc()` (escape HTML contra XSS), formatadores de data.
- **Casca:** `shell()` monta barra superior (logo, sino, tema, avatar), menu lateral (desktop), barra inferior + gaveta "Menu" (celular).
- **Telas:** objetos `ALUNO`, `PROF` e `COMUM` com uma função assíncrona por tela, que busca dados e devolve HTML.
- **Componentes:** `grade()` (grade por horários), `turmaGrupos()` (cartões por etapa), `calendario()`, `resumoAtvAluno()/resumoAtvProf()`, `formEvento()`, ícones SVG (`IC`).
- **Interação:** objetos `ACOES` (cliques via `data-act`), `SUBMIT` (formulários via `data-form`) e `CHANGE` (campos via `data-change`).
- **Tempo real:** `iniciarSessao()` abre o `EventSource`.

### 9.3 Telas e comportamentos relevantes

- **Cadastro:** turmas em cartões separados por etapa (Fundamental / Médio), com a quantidade de horários; aluno escolhe uma, professor marca várias. Campos de senha têm botão de mostrar/ocultar.
- **Grade de horários:** linhas = exatamente *N* horários da turma (sem linhas extras), colunas segunda–sexta, linhas de Intervalo/Almoço entre aulas. O professor vê células "+" para adicionar e clica numa aula própria para editar/excluir. Dados de outras matérias aparecem como "Ocupado".
- **Notas (professor):** tabela turma × matéria com 3 trimestres; cada campo salva ao sair (`change`), recalcula a média e dá retorno visual.
- **Calendário:** grade mensal (dom–sáb), navegação por mês, botão "Hoje"; ao clicar num dia abre o painel com os itens do dia e o formulário. Eventos aparecem em rosa; **prazos de atividades** aparecem em laranja, automaticamente.
- **Notificações:** sino com contador e menu rápido; página com filtro (todas/não lidas), marcar como lida/não lida, excluir e marcar todas.

### 9.4 Design e responsividade

- **Identidade:** paleta roxa (`--purple #6C2BD9`) com acentos rosa/laranja/amarelo/ciano, fontes Nunito (títulos) e DM Sans (texto), logo-mascote em `logo.webp`, ícones de menu em SVG de linha.
- **Tokens CSS** em `:root` (`app.css`); tema escuro via `[data-theme="dark"]`, alternado pelo botão da barra superior e lembrado em `localStorage`. `extra.css` define os tons escuros que faltavam (ex.: `--purple-light`).
- **Mobile (≤ 768 px):** barra inferior com 4 itens + "Menu" (gaveta com todas as páginas); grade de horários cabe na tela com dias abreviados; campos com 16 px e alvos de toque ≥ 40–44 px; respeito às áreas seguras (`env(safe-area-inset-*)`); popup do sino em largura total; calendário compacto com pontos coloridos.
- **Acessibilidade:** rótulos `aria-label` em botões de ícone, foco visível, `role="checkbox"`/`role="button"` com suporte a teclado onde necessário, `lang="pt-BR"`.

## 10. Segurança

| Medida | Onde |
|---|---|
| Content-Security-Policy estrita (`script-src 'self'`, sem JS inline; imagens `self`+`data:`; `frame-ancestors 'none'`) | `SEC` em `server.js` |
| Cabeçalhos `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer` | idem |
| Anti-CSRF: cookie `SameSite=Strict` + exigência de `application/json` + checagem do cabeçalho `Origin` | `server.js` |
| Escape de HTML em todo conteúdo dinâmico (`esc()`) e atributos | `app.js` |
| SQL sempre com parâmetros (`prepare` + `?`), nunca concatenação de entrada | `server.js` |
| Proteção contra *path traversal* nos arquivos estáticos | `server.js` |
| Limite de corpo (700 KB) e de tamanho de foto | `server.js` |
| Senhas com `scrypt` + *salt*; sessões guardadas como hash | `server.js` |
| Limite de tentativas de login | `server.js` |
| Resposta de erro interno sem detalhes ao cliente | `server.js` |

## 11. Testes

`npm test` (arquivo `test.js`) executa um servidor real com banco temporário e **102 verificações**, cobrindo:

- cadastro/login (senha divergente, e-mail duplicado, perfil trocado, senha errada);
- segurança básica (sem login, Content-Type, origem externa);
- entrega em tempo real via SSE;
- **notas:** professor só na própria matéria/turma; aluno nunca edita; aluno só vê as próprias;
- **horários:** limite por turma (5/7/9/6), conflitos de turma e de professor, dia inválido, permissões de edição/exclusão, grade filtrada ("Ocupado");
- **calendário:** datas inválidas, evento pessoal vs. de turma, visibilidade, notificação, edição/exclusão só do autor;
- **atividades, lembretes e avisos:** permissões, lembrete de prazo, marcação de concluída;
- **notificações:** marcar lida, excluir e isolamento entre usuários;
- **perfil:** troca de nome/senha e logout.

Também foi validada manualmente a migração de um banco antigo (dados preservados, `slot` calculado) e a interface em 375 px (celular) e 1200 px (desktop), nos temas claro e escuro.

## 12. Limitações conhecidas e próximos passos

- **Acesso local:** o servidor ouve só em `127.0.0.1`. Para uso em rede/Internet é preciso mudar o endereço de escuta, usar HTTPS (e marcar o cookie como `Secure`) e, de preferência, um proxy reverso.
- **Um único processo:** SQLite e as conexões SSE ficam em memória de um processo; não há escala horizontal.
- **Push com o navegador fechado:** não implementado (só notificação nativa com a aba aberta, em segundo plano).
- **Sem recuperação de senha por e-mail** e sem perfil de administrador (turmas oficiais são definidas no código).
- **Sem cadastro livre de turmas:** cada turma precisa de quantidade de horários definida; novas turmas entram por `TURMAS_OFICIAIS` em `db.js`.
- **Eventos antigos** (tabela `eventos`) não foram convertidos para o calendário por não terem data.
- **Backup:** copiar o arquivo `data/organizae.db` (com o servidor parado) preserva todos os dados.

## 13. Como estender

| Necessidade | Onde mexer |
|---|---|
| Nova turma ou mudar nº de horários | `TURMAS_OFICIAIS` em `db.js` (reiniciar o servidor) |
| Horários das aulas / intervalos | `SLOTS` em `db.js` e `PAUSAS` em `app.js` |
| Nova rota de API | `rota(método, caminho, {auth}, handler)` em `server.js`; valide com `txt/inteiro/hora` e cheque vínculo com `leciona`/`ensinaTurma`/`podeNota` |
| Nova tela | Função em `ALUNO`/`PROF`/`COMUM` + item em `MENU` + (se preciso) ícone em `IC` |
| Nova tabela/coluna | `CREATE TABLE IF NOT EXISTS` em `db.js` e, para bancos existentes, um `ALTER TABLE` condicional na seção de migração |
| Cores/tema | Tokens em `app.css` (`:root` e `[data-theme="dark"]`) e ajustes em `extra.css` |
