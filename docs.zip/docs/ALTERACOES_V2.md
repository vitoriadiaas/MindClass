# MindClass 2.0 — alterações

## Como usar
- Teste: `npm run teste:reset` (administrador `admin@teste.com`, senha `teste1234`, em `/#/entrar/administrador`).
- Uso real: `npm run criar-admin` (uma vez) e depois `npm start`.
- Produção com HTTPS: definir `COOKIE_SECURE=1`. `HOST` controla o endereço de escuta (padrão `127.0.0.1`).

## Falhas corrigidas
1. Professor escolhia as próprias turmas/matérias e já acessava alunos e notas. Agora exige aprovação da administração.
2. Login revelava contas pelo tempo de resposta; hash de senha bloqueava o servidor.
3. Sessões sem expiração por inatividade; trocar a senha não encerrava outras sessões.
4. Proteção anti-CSRF dependia só do cabeçalho `Origin`; limites de tentativas e conexões em tempo real sem teto.
5. Arquivo inexistente devolvia a página inicial em vez de 404.

## Funcionalidades novas
- **Administração:** visão geral, usuários (criar, editar, desativar, redefinir senha), aprovações, matérias, auditoria.
- **Segurança:** política de senhas, sessão de 7 dias com expiração após 12 h sem uso, "sair de todos os dispositivos", cabeçalhos extras.
- **Relatórios:** por aluno e por turma, filtros (turma, aluno, matéria, trimestre), gráficos, comparação entre trimestres, atenção, atividades, exportação em PDF pela impressão do navegador.
- **Histórico de notas:** criação, alteração e exclusão registradas automaticamente; registros imutáveis.
- **Calendário:** mês, semana e dia; categorias, matéria e turma; filtros; bloqueio de duplicados e conflitos; lembretes 48 h; próximos compromissos no início; atualização automática.
- **Desempenho:** `/api/painel`, compressão gzip, cache com ETag, índices, comandos SQL reaproveitados, cache de opções.

## Banco de dados
- `usuarios`: perfil `administrador`, colunas `ativo`, `ultimo_login`, `senha_alterada_em` (tabela reconstruída preservando os dados, com cópia de segurança automática).
- `professor_turmas` / `professor_materias`: `aprovado` (vínculos antigos ficam aprovados).
- `calendario`: `categoria`, `materia_id`. `sessoes`: `ultimo_uso`.
- Novas: `notas_historico` e `auditoria` (com gatilhos que impedem alterar ou apagar). Notas antigas entram no histórico como registro inicial.
- Script: `migracoes/002_historico_relatorios_calendario.sql` (aplicado por `db.js` ao iniciar).

## Arquivos
- Novos: `auth.js`, `admin.js`, `relatorios.js`, `criar-admin.js`, `migracoes/002_…sql`, `public/calendario.js`, `public/relatorios.js`, `public/historico.js`, `public/admin.js`, `public/modulos.css`.
- Modificados: `server.js`, `db.js`, `dev.js`, `test.js`, `package.json`, `public/app.js`, `public/index.html`.

## API nova
`/api/painel`, `/api/calendario`, `/api/logout-todas`, `/api/historico-notas`, `/api/relatorios/aluno`, `/api/relatorios/turma`, `/api/admin/*` (resumo, usuarios, pendencias, professores/:id/vinculos, materias, auditoria).

## Testes
- `npm test`: 190 verificações (segurança, permissões, administração, histórico, relatórios, calendário, tempo real, migração).
- Navegador: as 30 telas dos três perfis abertas sem erro; calendário, notas/histórico, relatórios, aprovação e edição de usuários exercitados; larguras de 375 e 820 px conferidas.
- Não testado: o PDF gerado pela impressão e a migração de um banco real em uso.

## Limitações
- O prompt não trazia a seção 2; o painel administrativo foi deduzido das demais seções.
- Alunos escolhem a própria turma no cadastro (a administração pode corrigir).
- O relatório de atividades não é dividido por trimestre. Sem recuperação de senha por e-mail.

## Notas por trimestre
- O ano tem 3 trimestres. A coluna do banco foi renomeada para `trimestre` automaticamente, com cópia de segurança.
- Se um banco antigo tiver notas no 4º período, elas continuam guardadas e aparecem no histórico, mas ficam fora das telas de notas e das médias.

## Supabase (PostgreSQL)
- Com `DATABASE_URL` no arquivo `.env`, o servidor grava no PostgreSQL; sem ele (e nos testes), usa o SQLite local.
- Tabelas: `supabase/schema.sql`. Modelo do `.env`: `.env.exemplo`.
- `npm run criar-admin` cria o administrador no banco configurado; `npm run copiar-supabase` copia contas reais do banco local.
- Dependência nova: `pg`. Arquivos novos: `db-sqlite.js`, `db-postgres.js`, `dados.js`, `copiar-para-supabase.js`.
- `npm test` (190 verificações) roda no SQLite. O caminho PostgreSQL ainda não foi testado contra o banco real.
