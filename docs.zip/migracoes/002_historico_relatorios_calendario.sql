-- MindClass v2 — histórico de notas, auditoria, índices.
-- Idempotente: pode ser executado várias vezes (é aplicado automaticamente por db.js ao iniciar).
-- Não remove nem altera dados existentes. As colunas novas (ativo, aprovado, categoria, materia_id,
-- ultimo_uso…) são adicionadas por db.js com ALTER TABLE condicional, pois o SQLite não tem "ADD COLUMN IF NOT EXISTS".

-- ============ HISTÓRICO DE NOTAS (imutável) ============
CREATE TABLE IF NOT EXISTS notas_historico(
  id INTEGER PRIMARY KEY,
  aluno_id INTEGER NOT NULL REFERENCES alunos(usuario_id),
  materia_id INTEGER NOT NULL REFERENCES materias(id),
  turma_id INTEGER REFERENCES turmas(id),
  trimestre INTEGER NOT NULL CHECK(trimestre BETWEEN 1 AND 4),
  ano_letivo INTEGER NOT NULL,
  acao TEXT NOT NULL CHECK(acao IN ('criada','alterada','excluida')),
  valor_anterior REAL,
  valor_novo REAL,
  professor_id INTEGER REFERENCES usuarios(id),
  alterado_por INTEGER NOT NULL REFERENCES usuarios(id),
  alterado_em TEXT NOT NULL,
  origem TEXT NOT NULL DEFAULT 'sistema'
);
-- Registros do histórico nunca podem ser alterados nem apagados (nem pela aplicação, nem por SQL direto).
CREATE TRIGGER IF NOT EXISTS notas_historico_sem_update BEFORE UPDATE ON notas_historico
BEGIN SELECT RAISE(ABORT, 'O historico de notas e imutavel.'); END;
CREATE TRIGGER IF NOT EXISTS notas_historico_sem_delete BEFORE DELETE ON notas_historico
BEGIN SELECT RAISE(ABORT, 'O historico de notas e imutavel.'); END;

-- ============ AUDITORIA ADMINISTRATIVA ============
CREATE TABLE IF NOT EXISTS auditoria(
  id INTEGER PRIMARY KEY,
  usuario_id INTEGER REFERENCES usuarios(id),
  acao TEXT NOT NULL,
  alvo TEXT,
  detalhe TEXT,
  ip TEXT,
  em TEXT NOT NULL
);
CREATE TRIGGER IF NOT EXISTS auditoria_sem_update BEFORE UPDATE ON auditoria
BEGIN SELECT RAISE(ABORT, 'A auditoria e imutavel.'); END;
CREATE TRIGGER IF NOT EXISTS auditoria_sem_delete BEFORE DELETE ON auditoria
BEGIN SELECT RAISE(ABORT, 'A auditoria e imutavel.'); END;

-- ============ ÍNDICES ============
CREATE INDEX IF NOT EXISTS ix_hist_aluno   ON notas_historico(aluno_id, alterado_em DESC);
CREATE INDEX IF NOT EXISTS ix_hist_materia ON notas_historico(materia_id, trimestre);
CREATE INDEX IF NOT EXISTS ix_hist_turma   ON notas_historico(turma_id, alterado_em DESC);
CREATE INDEX IF NOT EXISTS ix_hist_data    ON notas_historico(alterado_em DESC);
CREATE INDEX IF NOT EXISTS ix_aud_data     ON auditoria(em DESC);

CREATE INDEX IF NOT EXISTS ix_hor_turma    ON horarios(turma_id, dia, slot);
CREATE INDEX IF NOT EXISTS ix_hor_prof     ON horarios(professor_id, dia, slot);
CREATE INDEX IF NOT EXISTS ix_notas_materia ON notas(materia_id);
CREATE INDEX IF NOT EXISTS ix_atv_turma    ON atividades(turma_id, prazo);
CREATE INDEX IF NOT EXISTS ix_atv_prof     ON atividades(professor_id, prazo);
CREATE INDEX IF NOT EXISTS ix_conc_atv     ON atividades_concluidas(atividade_id);
CREATE INDEX IF NOT EXISTS ix_aluno_turmas_turma ON aluno_turmas(turma_id);
CREATE INDEX IF NOT EXISTS ix_prof_turmas_turma  ON professor_turmas(turma_id);
CREATE INDEX IF NOT EXISTS ix_prof_mat_materia   ON professor_materias(materia_id);
CREATE INDEX IF NOT EXISTS ix_cal_turma    ON calendario(turma_id, data);
CREATE INDEX IF NOT EXISTS ix_cal_usuario  ON calendario(usuario_id, data);
CREATE INDEX IF NOT EXISTS ix_cal_data     ON calendario(data);
CREATE INDEX IF NOT EXISTS ix_sess_usuario ON sessoes(usuario_id);
CREATE INDEX IF NOT EXISTS ix_usuarios_perfil ON usuarios(perfil, ativo);
